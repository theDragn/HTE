package world;

import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Items;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketConditionAPI;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarGenDataSpec;
import com.fs.starfarer.api.impl.campaign.terrain.StarCoronaTerrainPlugin.CoronaParams;

import java.util.Arrays;
import java.util.ArrayList;
import plugins.drgModPlugin;

import java.awt.Color;

public class drgZarmazd
{
    public void generate(SectorAPI sector)
    {
        if (!drgModPlugin.ZARMAZD_ENABLED)
            return;
        StarSystemAPI system = sector.createStarSystem("Zarmazd");
        system.getLocation().set(drgModPlugin.ZARMAZD_X, drgModPlugin.ZARMAZD_Y);
        system.setBackgroundTextureFilename("graphics/backgrounds/background6.jpg");
        // blatantly stolen code
        PlanetAPI star = system.initStar("drg_zarmazd_star", StarTypes.BLACK_HOLE, 225f, 0);
        star.getSpec().setBlackHole(true);
        system.setLightColor(new Color(135, 110, 110));

        StarGenDataSpec starData = (StarGenDataSpec) Global.getSettings().getSpec(StarGenDataSpec.class, star.getSpec().getPlanetType(), false);
        float corona = (float) (star.getRadius() * (starData.getCoronaMult() + starData.getCoronaVar() * (Math.random() - 0.5f)));
        if (corona < starData.getCoronaMin()) {
            corona = starData.getCoronaMin();
        }
        SectorEntityToken eventHorizon = system.addTerrain(Terrain.EVENT_HORIZON,
                new CoronaParams(star.getRadius() + corona, (star.getRadius() + corona) / 2f,
                        star, starData.getSolarWind(),
                        (float) (starData.getMinFlare() + (starData.getMaxFlare() - starData.getMinFlare()) * Math.random()),
                        starData.getCrLossMult()));
        eventHorizon.setCircularOrbit(star, 0, 0, 100);

        /*SectorEntityToken eventHorizon = system.addTerrain(Terrain.EVENT_HORIZON,
        new EventHorizonPlugin.CoronaParams(1000,
                800,
                star,
                -9f,
                0f,
                20f));*/

        // accretion disks are cool!
        // also stolen code
        system.addRingBand(star, "misc", "rings_dust0", 1024f, 3, Color.white, 1024f, 1100, 400f, Terrain.RING,
                null);
        system.addRingBand(star, "misc", "rings_ice0", 256f, 3, Color.white, 256f, 1100 - 50f, 300f, null, null);
        system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1100 - 100f, 200f, null, null);
        system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1100 - 150f, 100f, null, null);
        system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.white, 256f, 1100 + 200f, 200f, null, null);
        system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 256f, 1100 + 300f, 125f, null, null);
        system.addRingBand(star, "misc", "rings_dust0", 256f, 1, Color.magenta, 350f, 1100 + 350f, 200f, null, null);
        system.addRingBand(star, "misc", "rings_dust0", 256f, 2, Color.white, 512f, 1100 + 400f, 125f, Terrain.RING, null);

        // add our one lonely planet
        PlanetAPI planet = system.addPlanet("drg_svarog_planet", star, "Svarog", "tundra", 30f, 140f, 4000f, 270f);
        planet.setCustomDescriptionId("drg_svarog");
        // add comm relay for stability
        SectorEntityToken commRelay = system.addCustomEntity(
            "drg_zarmazd_relay",
            "Comm Relay",
            Entities.COMM_RELAY,
            Factions.INDEPENDENT
        );
        commRelay.setCircularOrbit(star, 245f, 4500f, 950f);

        // a lil asteroid belt to hold up our asteroid pants
        system.addAsteroidBelt(
            star, //orbit focus
            80, //number of asteroid entities
            3000, //orbit radius is 500 gap for outer randomly generated entity above
            300, //width of band
            190, //minimum and maximum visual orbit speeds of asteroids
            220,
            Terrain.ASTEROID_BELT, //ID of the terrain type that appears in the section above the abilities bar
            "Zarmazd Asteroid Belt" //display name
        );
    
            //add a ring texture. it will go under the asteroid entities generated above
        system.addRingBand(star,
            "misc", //used to access band texture, this is the name of a category in settings.json
            "rings_asteroids0", //specific texture id in category misc in settings.json
            256f, //texture width, can be used for scaling shenanigans
            2,
            Color.white, //colour tint
            256f, //band width in game
            3300, //same as above
            200f,
            null,
            null
        );

        //and our lonely market for our lonely planet :( all by itself, it needs you to be its friend
        MarketAPI market = Global.getFactory().createMarket("drg_svarog_market", "Svarog", 5);
        market.setPrimaryEntity(planet);
        planet.setMarket(market);
        planet.setFaction(Factions.INDEPENDENT);
        market.setFactionId(Factions.INDEPENDENT);
        market.getTariff().modifyFlat("gen", market.getFaction().getTariffFraction());
        market.addSubmarket(Submarkets.SUBMARKET_OPEN);
        market.addSubmarket(Submarkets.SUBMARKET_STORAGE);
        market.addSubmarket(Submarkets.GENERIC_MILITARY);
        if (drgModPlugin.SVAROG_OUTPOST_MARKET_ENABLED)
        {
            market.addSubmarket("drg_SvarogMarket");
        }
        market.addSubmarket(Submarkets.SUBMARKET_BLACK);

        market.addCondition(Conditions.COLD);
        market.addCondition(Conditions.HABITABLE);
        market.addCondition(Conditions.LOW_GRAVITY);
        market.addCondition(Conditions.TECTONIC_ACTIVITY);
        market.addCondition(Conditions.POPULATION_5);

        market.addIndustry(Industries.POPULATION);
        market.addIndustry(Industries.MEGAPORT);
        market.addIndustry(Industries.ORBITALWORKS, new ArrayList<>(Arrays.asList(Items.PRISTINE_NANOFORGE)));
        market.addIndustry(Industries.STARFORTRESS_HIGH);
        market.addIndustry(Industries.REFINING);
        market.addIndustry(Industries.HEAVYBATTERIES);
        market.addIndustry(Industries.HIGHCOMMAND);

        for (MarketConditionAPI mc : market.getConditions())
        {
            mc.setSurveyed(true);
        }
        market.setSurveyLevel(MarketAPI.SurveyLevel.FULL);
        market.reapplyIndustries();
        Global.getSector().getEconomy().addMarket(market, true);

        // autogenerate jump points that will appear in hyperspace and in system
        system.autogenerateHyperspaceJumpPoints(true, true);

        // the following is hyperspace cleanup code that will remove hyperstorm clouds around this system's location in hyperspace
        // don't need to worry about this, it's more or less copied from vanilla

        // set up hyperspace editor plugin
        HyperspaceTerrainPlugin hyperspaceTerrainPlugin = (HyperspaceTerrainPlugin) Misc.getHyperspaceTerrain()
                .getPlugin(); // get instance of hyperspace terrain
        NebulaEditor nebulaEditor = new NebulaEditor(hyperspaceTerrainPlugin); // object used to make changes to hyperspace nebula

        // set up radiuses in hyperspace of system
        float minHyperspaceRadius = hyperspaceTerrainPlugin.getTileSize() * 2.5f;
        float maxHyperspaceRadius = system.getMaxRadiusInHyperspace();

        // hyperstorm-b-gone (around system in hyperspace)
        nebulaEditor.clearArc(system.getLocation().x, system.getLocation().y, 0,
                minHyperspaceRadius + maxHyperspaceRadius, 0f, 360f, 0.25f);
    }
}
