package data.shipsystems.scripts;

import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.combat.entities.ship.O0OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO;

import java.awt.*;

// venting? idk that's pretty sus
public class drgMicroVent extends BaseShipSystemScript
{

    public static final float VENT_BOOST = 1.5f; // vent rate = dissipation * this
    private boolean runOnce = false;
    private boolean reactivateShield = false;

    @Override
    public void apply(MutableShipStatsAPI stats, String id, ShipSystemStatsScript.State state, float effectLevel)
    {

        stats.getFluxDissipation().modifyMult(id, VENT_BOOST);
        ShipAPI ship = (ShipAPI)stats.getEntity();
        if (!runOnce)
        {
            runOnce = true;
            reactivateShield = ship.getShield().isOn();
        }
        FluxTrackerAPI fluxTracker = ship.getFluxTracker();
        // welcome to jank city baby
        // don't tell alex
        ((O0OOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO)fluxTracker).ventFlux();
    }

    @Override
    public void unapply(MutableShipStatsAPI stats, String id)
    {
        runOnce = false;
        stats.getFluxDissipation().unmodify(id);
        ShipAPI ship = (ShipAPI)stats.getEntity();
        ship.getFluxTracker().stopVenting();
        if (reactivateShield)
            ship.getShield().toggleOn();
        reactivateShield = false;
    }

    @Override
    public ShipSystemStatsScript.StatusData getStatusData(int index, ShipSystemStatsScript.State state, float effectLevel) {
        /*if (index == 0)
            return new ShipSystemStatsScript.StatusData("+" + (int)(BASE_SPEED_FLAT * boostMult * effectLevel) + " top speed", false);
        if (index == 1)
            return new ShipSystemStatsScript.StatusData("+" + (int)(BASE_MANEUVERING_PERCENT * boostMult * effectLevel) + "% maneuverability", false);*/
        return null;
    }

}
