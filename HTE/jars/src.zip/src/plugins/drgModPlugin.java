package plugins;

import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;

import data.weapons.proj.ai.drgKneecapperMissileAI;

import java.io.IOException;
import org.json.JSONException;
import org.json.JSONObject;
import org.apache.log4j.Logger;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.impl.campaign.procgen.ProcgenUsedNames;

public class drgModPlugin extends BaseModPlugin
{
    public static final String SETTINGS_FILE = "HTE_SETTINGS.json";
    public static Logger log = Global.getLogger(drgModPlugin.class);

    public static boolean loaded = false;
    public static boolean SVAROG_OUTPOST_MARKET_ENABLED;
    public static boolean SVAROG_SELL_RARE_BP;
    public static boolean ZARMAZD_ENABLED;
    public static float AI_UPDATE_INTERVAL;
    public static float AI_FLUXCOMP_TRIGGER;
    public static float AI_RANGECLOCK_ACTIVATE;
    public static float AI_RANGECLOCK_DEACTIVATE;
    public static float SVAROG_TARIFF;
    public static float SVAROG_WEIGHT_FRIGATE;
    public static float SVAROG_WEIGHT_DESTROYER;
    public static float SVAROG_WEIGHT_CRUISER;
    public static float SVAROG_WEIGHT_CAPITAL;
    public static float SVAROG_WEIGHT_IV;
    public static float SVAROG_WEIGHT_XIV;
    public static float SVAROG_WEIGHT_HIGHTECH;
    public static float SVAROG_WEIGHT_MIDLINE;
    public static float SVAROG_WEIGHT_RARE;
    public static float ZARMAZD_X;
    public static float ZARMAZD_Y;
    public static int SVAROG_NUM_WEAPONS;
    public static int SVAROG_NUM_WINGS;
    public static int SVAROG_NUM_HULLS;

    @Override
    public void onApplicationLoad()
    {
        boolean hasLazyLib = Global.getSettings().getModManager().isModEnabled("lw_lazylib");
        if (!hasLazyLib)
            throw new RuntimeException(
                    "HTE requires LazyLib.\nGet it at http://fractalsoftworks.com/forum/index.php?topic=5444");

        boolean hasMagicLib = Global.getSettings().getModManager().isModEnabled("MagicLib");
        if (!hasMagicLib)
            throw new RuntimeException(
                    "HTE requires MagicLib.\nGet it at http://fractalsoftworks.com/forum/index.php?topic=13718");

        // detecting things by mod id is boomer coding
        // boolean a = Global.getSettings().getModManager().isModEnabled(de("bmV3X2dhbGFjdGljX29yZGVy"));
        // boolean b = Global.getSettings().getModManager().isModEnabled(de("YXJpYQ=="));
        // if (a || b)
        // throw new RuntimeException(de("SFRFIGVycm9yOiBUaGlzIG1vZCBpcyBub3QgY29tcGF0aWJsZSB3aXRoIE5HTyBvciBBcmlhLiBQbGVhc2UgZGlzYWJsZSBIVEUgb3IgdGhlIGNvbmZsaWN0aW5nIG1vZCBhbmQgcmVzdGFydCB5b3VyIGdhbWUu"));

        // cool kids use class detection
        // try changing the mod id now, fucko
        // fash b gone 2: electric boogaloo
        boolean b = false;
        try
        {
            Global.getSettings().getScriptClassLoader().loadClass(de("ZGF0YS5zY3JpcHRzLkFSSUFNb2RQbHVnaW4="));
            b = true;
        } catch (ClassNotFoundException e) {}
        try
        {
            Global.getSettings().getScriptClassLoader().loadClass(de("ZGF0YS5zY3JpcHRzLk5HT01vZFBsdWdpbg=="));
            b = true;
        } catch (ClassNotFoundException e) {}
        if (b)
        {
            // All hidden behavior has been removed. If there's something wrong, it'll error out as soon as it can.
            // "something wrong" includes not loading the mod plugin, by the way
            // alas, surprise doots were not meant to be
            // at least one guy got dooted, though, which is great.
            throw new RuntimeException(de("SFRFIGVycm9yOiBUaGlzIG1vZCBpcyBub3QgY29tcGF0aWJsZSB3aXRoIE5HTyBvciBBcmlhLiBQbGVhc2UgZGlzYWJsZSBIVEUgb3IgdGhlIGNvbmZsaWN0aW5nIG1vZCBhbmQgcmVzdGFydCB5b3VyIGdhbWUu"));
        }

        try
        {
            loadHTEsettings();
        } catch (Exception e)
        {
            // could probably make it fail gracefully but that would likely cause confusing behavior
            // crash early and notify the user rather than allowing confusion- it's easy to fix by redownloading
            throw new RuntimeException(
                    "HTE encountered a \"bruh moment\".\nAnd by that I mean there was an issue with the settings file.");
        }
    }

    @Override
    public void onNewGame()
    {
        (new drgSectorGenerator()).generate(Global.getSector());
        ProcgenUsedNames.notifyUsed("Svarog");
    }

    @Override
    public void onGameLoad(boolean newGame)
    {
        SectorAPI sector = Global.getSector();
        if (!sector.hasScript(drgFleetStatManager.class))
        {
            sector.addScript((EveryFrameScript) new drgFleetStatManager());
        }
    }

    @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(MissileAPI missile, ShipAPI launchingShip) {
        switch (missile.getProjectileSpecId()) { 
            case "drg_kneecapper_rocket":
                return new PluginPick<MissileAIPlugin>(new drgKneecapperMissileAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            default:
        }
        return null;
    }

    private static void loadHTEsettings() throws IOException, JSONException
    {
        JSONObject settings = Global.getSettings().loadJSON(SETTINGS_FILE);
        log.info("Loaded HTE settings json");
        loaded = true;
        SVAROG_OUTPOST_MARKET_ENABLED = settings.getBoolean("svarogOutpostMarketEnabled");
        ZARMAZD_ENABLED = settings.getBoolean("zarmazdSystemEnabled");
        ZARMAZD_X = (float) settings.getDouble("zarmazdX");
        ZARMAZD_Y = (float) settings.getDouble("zarmazdY");
        SVAROG_TARIFF = (float) settings.getDouble("svarogSpecialtyMarketTariff");
        SVAROG_WEIGHT_FRIGATE = (float) settings.getDouble("svarogWeightFrigate");
        SVAROG_WEIGHT_DESTROYER = (float) settings.getDouble("svarogWeightDestroyer");
        SVAROG_WEIGHT_CRUISER = (float) settings.getDouble("svarogWeightCruiser");
        SVAROG_WEIGHT_CAPITAL = (float) settings.getDouble("svarogWeightCapital");
        SVAROG_WEIGHT_IV = (float) settings.getDouble("svarogWeightIV");
        SVAROG_WEIGHT_XIV = (float) settings.getDouble("svarogWeightXIV");
        SVAROG_WEIGHT_HIGHTECH = (float) settings.getDouble("svarogWeightHightech");
        SVAROG_WEIGHT_MIDLINE = (float) settings.getDouble("svarogWeightMidline");
        SVAROG_WEIGHT_RARE = (float) settings.getDouble("svarogWeightRare");
        SVAROG_NUM_WEAPONS = settings.getInt("svarogNumWeapons");
        SVAROG_NUM_WINGS = settings.getInt("svarogNumWings");
        SVAROG_NUM_HULLS = settings.getInt("svarogNumHulls");
        AI_UPDATE_INTERVAL = (float) settings.getDouble("aiUpdateInterval");
        AI_FLUXCOMP_TRIGGER = (float) settings.getDouble("aiFluxCompressorThreshold");
        AI_RANGECLOCK_ACTIVATE = (float) settings.getDouble("aiRangeOverclockActivateMax");
        AI_RANGECLOCK_DEACTIVATE = (float) settings.getDouble("aiRangeOverclockDeactivateAt");
    }

    // plugin is responsible for lots of things now
    // disabling it will do weird things
    // and I know at least one guy disabled it, so here's an error just for you
    // but also, in general, better to crash early and notify the user rather than allowing weirdness
    public static void checkPluginLoading()
    {
        if (!drgModPlugin.loaded)
        {
            throw new RuntimeException("HTE error: mod plugin was never loaded. Something has probably gone horribly wrong if you're seeing this.");
        }
    }

    // Obfuscation really isn't useful at this point, but it was a pain in the ass to write so I'm not gonna let it go to waste
    public static String de(String q)
    {
        String u = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
        q = q.replaceAll("[^" + u + "=]", "");
        String t = (q.charAt(q.length() - 1) == '=' ? (q.charAt(q.length() - 2) == '=' ? "AA" : "A") : "");
        String r = "";
        q = q.substring(0, q.length() - t.length()) + t;
        for (int v = 0; v < q.length(); v += 4)
        {
            int s = (u.indexOf(q.charAt(v)) << 18) + (u.indexOf(q.charAt(v + 1)) << 12)
                    + (u.indexOf(q.charAt(v + 2)) << 6) + u.indexOf(q.charAt(v + 3));
            r += "" + (char) ((s >>> 16) & 0xFF) + (char) ((s >>> 8) & 0xFF) + (char) (s & 0xFF);
        }
        return r.substring(0, r.length() - t.length());
    }
}
