package plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SubmarketPlugin;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.HashMap;
import java.util.Map;

public class drgSvarogMarketPlugin extends BaseSubmarketPlugin
{
    private static final RepLevel MIN_STANDING = RepLevel.COOPERATIVE;
    private WeightedRandomPicker<ShipHullSpecAPI> ivPicker;
    private WeightedRandomPicker<ShipHullSpecAPI> xivPicker;
    private WeightedRandomPicker<ShipHullSpecAPI> hightechPicker;
    private WeightedRandomPicker<ShipHullSpecAPI> midlinePicker;
    private WeightedRandomPicker<ShipHullSpecAPI> rarePicker;

    // this is your brain on recursion
    private WeightedRandomPicker<WeightedRandomPicker<ShipHullSpecAPI>> pickerPicker;

    @Override
    public void init(SubmarketAPI submarket)
    {
        drgModPlugin.checkPluginLoading();
        super.init(submarket);
        ivPicker = getHullPicker("IV_bp");
        xivPicker = getHullPicker("XIV_bp");
        hightechPicker = getHullPicker("hightech_bp");
        midlinePicker = getHullPicker("midline_bp");
        rarePicker = getHullPicker("rare_bp");
        pickerPicker = new WeightedRandomPicker<>();
        pickerPicker.add(ivPicker, drgModPlugin.SVAROG_WEIGHT_IV);
        pickerPicker.add(xivPicker, drgModPlugin.SVAROG_WEIGHT_XIV);
        pickerPicker.add(hightechPicker, drgModPlugin.SVAROG_WEIGHT_HIGHTECH);
        pickerPicker.add(midlinePicker, drgModPlugin.SVAROG_WEIGHT_MIDLINE);
        pickerPicker.add(rarePicker,drgModPlugin.SVAROG_WEIGHT_RARE);
    }

    @Override
    public float getTariff()
    {
        return drgModPlugin.SVAROG_TARIFF;
    }

    @Override
    public String getTooltipAppendix(CoreUIAPI ui)
    {
        RepLevel level = this.submarket.getFaction().getRelationshipLevel(Global.getSector().getFaction("player"));
        if (!level.isAtWorst(MIN_STANDING))
            return "Requires: " + this.submarket.getFaction().getDisplayName() + " - "
                    + MIN_STANDING.getDisplayName().toLowerCase();
        if (!Global.getSector().getPlayerFleet().isTransponderOn())
            return "Requires: Fleet identification. Turn on your transponder.";
        return super.getTooltipAppendix(ui);
    }

    @Override
    public boolean isEnabled(CoreUIAPI ui)
    {
        if (!Global.getSector().getPlayerFleet().isTransponderOn())
            return false;
        RepLevel level = this.submarket.getFaction().getRelationshipLevel(Global.getSector().getFaction("player"));
        return level.isAtWorst(MIN_STANDING);
    }

    @Override
    public void updateCargoPrePlayerInteraction()
    {
        this.sinceLastCargoUpdate = 0.0F;
        if (okToUpdateShipsAndWeapons())
        {            
            this.sinceSWUpdate = 0.0F;

            // add weapons from a mix of tritach, indy, and persean
            pruneWeapons(0.0F);
            int weapons = drgModPlugin.SVAROG_NUM_WEAPONS / 2;
            int fighters = drgModPlugin.SVAROG_NUM_WINGS / 2;
            addWeapons(weapons, weapons + 4, 4, Factions.PERSEAN);
            addFighters(fighters, fighters + 2, 3, Factions.PERSEAN);
            addWeapons(weapons, weapons + 4, 4, Factions.TRITACHYON);
            addFighters(fighters, fighters + 2, 3, Factions.TRITACHYON);


            getCargo().getMothballedShips().clear();
            for (int i = 0; i < drgModPlugin.SVAROG_NUM_HULLS; i++)
            {
                ShipHullSpecAPI hull = null;
                WeightedRandomPicker<ShipHullSpecAPI> picker = pickerPicker.pick();
                hull = picker.pick();
                addShip(hull.getHullId() + "_Hull", false, 250f);
            }
            addHullMods(4, 5);
        }
        getCargo().sort();
    }

    private WeightedRandomPicker<ShipHullSpecAPI> getHullPicker(String tag)
    {
        Map<HullSize,Float> hullWeights = new HashMap<>();
        hullWeights.put(HullSize.FRIGATE, drgModPlugin.SVAROG_WEIGHT_FRIGATE);
        hullWeights.put(HullSize.DESTROYER, drgModPlugin.SVAROG_WEIGHT_DESTROYER);
        hullWeights.put(HullSize.CRUISER, drgModPlugin.SVAROG_WEIGHT_CRUISER);
        hullWeights.put(HullSize.CAPITAL_SHIP, drgModPlugin.SVAROG_WEIGHT_CAPITAL);

        WeightedRandomPicker<ShipHullSpecAPI> picker = new WeightedRandomPicker<>();
        for (ShipHullSpecAPI hull : Global.getSettings().getAllShipHullSpecs())
        {
            if (hull.hasTag(tag))
            {
                if (hullWeights.containsKey(hull.getHullSize()))
                    picker.add(hull, 10 * hullWeights.get(hull.getHullSize()));
            }
        }
        return picker;
    }

    @Override
    public boolean isIllegalOnSubmarket(CargoStackAPI stack, SubmarketPlugin.TransferAction action)
    {
        if (action == SubmarketPlugin.TransferAction.PLAYER_SELL)
            return true;
        return false;
    }

    @Override
    public boolean isIllegalOnSubmarket(String commodityId, SubmarketPlugin.TransferAction action)
    {
        if (action == SubmarketPlugin.TransferAction.PLAYER_SELL)
            return true;
        return false;
    }

    @Override
    public boolean isIllegalOnSubmarket(FleetMemberAPI member, SubmarketPlugin.TransferAction action)
    {
        if (action == SubmarketPlugin.TransferAction.PLAYER_SELL)
            return true;
        return false;
    }

    @Override
    public String getIllegalTransferText(CargoStackAPI stack, SubmarketPlugin.TransferAction action)
    {
        return "No sales";
    }

    @Override
    public String getIllegalTransferText(FleetMemberAPI member, SubmarketPlugin.TransferAction action)
    {
        return "No sales";
    }

    /*public String getIllegalTransferText(String commodityId, SubmarketPlugin.TransferAction action)
    {
        return "No sales";
    }*/

    protected Object writeReplace()
    {
        if (okToUpdateShipsAndWeapons())
        {
            pruneWeapons(0.0F);
            getCargo().getMothballedShips().clear();
        }
        return this;
    }
}
